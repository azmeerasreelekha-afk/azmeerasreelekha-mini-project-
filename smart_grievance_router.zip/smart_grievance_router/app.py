from flask import Flask, render_template, request, jsonify
from datetime import datetime
import random
import string

app = Flask(__name__)

# ─────────────────────────────────────────────
#  Department keyword rules
# ─────────────────────────────────────────────
DEPARTMENT_RULES = [
    {
        "name": "Water Department",
        "keywords": ["water", "leakage", "leak", "pipe", "tap", "drainage", "flood", "sewage"],
        "icon": "💧",
        "color": "#3b82f6",
        "sla": "48 hours",
        "contact": "water@smartcity.gov",
    },
    {
        "name": "Electricity Department",
        "keywords": ["electricity", "electric", "power", "current", "voltage", "transformer",
                     "wire", "outage", "blackout", "light", "streetlight"],
        "icon": "⚡",
        "color": "#f59e0b",
        "sla": "24 hours",
        "contact": "electricity@smartcity.gov",
    },
    {
        "name": "Roads Department",
        "keywords": ["road", "pothole", "street", "highway", "pavement", "footpath",
                     "traffic", "signal", "divider", "bridge"],
        "icon": "🛣️",
        "color": "#10b981",
        "sla": "72 hours",
        "contact": "roads@smartcity.gov",
    },
    {
        "name": "Sanitation Department",
        "keywords": ["garbage", "waste", "cleaning", "trash", "dustbin", "bin", "litter",
                     "smell", "sewage", "drain", "hygiene", "dirty"],
        "icon": "♻️",
        "color": "#8b5cf6",
        "sla": "36 hours",
        "contact": "sanitation@smartcity.gov",
    },
]

GENERAL_DEPT = {
    "name": "General Department",
    "icon": "🏛️",
    "color": "#64748b",
    "sla": "96 hours",
    "contact": "general@smartcity.gov",
}


def generate_ticket_id():
    chars = string.ascii_uppercase + string.digits
    return "GR-" + "".join(random.choices(chars, k=8))


def route_complaint(text: str) -> dict:
    """Keyword-based routing logic."""
    lower = text.lower()
    for dept in DEPARTMENT_RULES:
        for kw in dept["keywords"]:
            if kw in lower:
                return dept
    return GENERAL_DEPT


# In-memory complaint log (resets on server restart)
complaints_log = []


# ─────────────────────────────────────────────
#  Routes
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit():
    data = request.get_json()
    name = data.get("name", "").strip()
    complaint = data.get("complaint", "").strip()

    if not name or not complaint:
        return jsonify({"error": "Name and complaint are required."}), 400

    dept = route_complaint(complaint)
    ticket_id = generate_ticket_id()
    timestamp = datetime.now().strftime("%d %b %Y, %I:%M %p")

    entry = {
        "ticket_id": ticket_id,
        "name": name,
        "complaint": complaint,
        "department": dept["name"],
        "icon": dept["icon"],
        "color": dept["color"],
        "sla": dept["sla"],
        "contact": dept["contact"],
        "timestamp": timestamp,
        "status": "Received",
    }
    complaints_log.append(entry)

    return jsonify(entry)


@app.route("/complaints")
def complaints():
    return jsonify(complaints_log)


if __name__ == "__main__":
    app.run(debug=True)
