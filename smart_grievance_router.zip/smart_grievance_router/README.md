# 🏛️ Smart Grievance Router
### AI-Powered Citizen Complaint Routing System
> Mini Project · 2nd Year Engineering · 2025–26

---

## 📁 Project Structure

```
smart_grievance_router/
│
├── app.py                  ← Flask backend (routing logic + API endpoints)
├── requirements.txt        ← Python dependencies
├── README.md               ← This file
│
└── templates/
    └── index.html          ← Frontend (HTML + CSS + JavaScript, all-in-one)
```

---

## 🚀 How to Run

### Step 1 — Install Python
Make sure Python 3.8+ is installed.
```bash
python --version
```

### Step 2 — Create a Virtual Environment (recommended)
```bash
python -m venv venv

# Activate on Windows:
venv\Scripts\activate

# Activate on Mac/Linux:
source venv/bin/activate
```

### Step 3 — Install Flask
```bash
pip install -r requirements.txt
```

### Step 4 — Run the App
```bash
python app.py
```

### Step 5 — Open in Browser
Visit: **http://127.0.0.1:5000**

---

## 🧠 How the Code Works

### 1. Backend — `app.py`

#### A. Department Rules Dictionary
```python
DEPARTMENT_RULES = [
    {
        "name": "Water Department",
        "keywords": ["water", "leakage", "pipe", ...],
        ...
    },
    ...
]
```
Each department has a list of keywords. When a complaint comes in, the system checks which department's keywords appear in the complaint text.

#### B. Routing Function
```python
def route_complaint(text: str) -> dict:
    lower = text.lower()          # Convert to lowercase for case-insensitive matching
    for dept in DEPARTMENT_RULES:
        for kw in dept["keywords"]:
            if kw in lower:       # If keyword found → return that department
                return dept
    return GENERAL_DEPT           # No match → General Department
```
This is simple keyword-based logic. No ML or AI involved.

#### C. Flask Routes
| Route       | Method | Purpose                              |
|-------------|--------|--------------------------------------|
| `/`         | GET    | Serves the HTML page                 |
| `/submit`   | POST   | Receives complaint JSON, routes it, returns result |
| `/complaints` | GET  | Returns all complaints (log viewer)  |

#### D. Ticket ID Generation
```python
def generate_ticket_id():
    chars = string.ascii_uppercase + string.digits
    return "GR-" + "".join(random.choices(chars, k=8))
# Example output: GR-X7K2MN4A
```

---

### 2. Frontend — `templates/index.html`

#### A. Form Submission (JavaScript)
```javascript
async function submitComplaint() {
    const res = await fetch('/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, complaint }),
    });
    const data = await res.json();
    // Display the result card with department info
}
```
Uses the **Fetch API** to send data to Flask without page reload (AJAX).

#### B. Live Keyword Highlighting
As the user types, JavaScript checks for department keywords and highlights the relevant department chip in real time.

#### C. Result Display
After submission, the form is hidden and a result card is shown with:
- Ticket ID (unique per complaint)
- Department assigned
- SLA (expected response time)
- Contact email
- Timestamp

---

## 🏢 Department Routing Logic

| Department         | Keywords                                        | SLA    |
|--------------------|-------------------------------------------------|--------|
| 💧 Water           | water, leakage, leak, pipe, tap, drain, sewage  | 48 hrs |
| ⚡ Electricity      | electricity, power, current, outage, light      | 24 hrs |
| 🛣️ Roads           | road, pothole, street, highway, footpath        | 72 hrs |
| ♻️ Sanitation      | garbage, waste, cleaning, trash, dirty, smell   | 36 hrs |
| 🏛️ General        | (no keyword match)                              | 96 hrs |

---

## 🧪 Test Complaints

Try submitting these to test routing:
- `"There is water leakage near my house"` → 💧 Water Department
- `"Power outage for 3 hours in our area"` → ⚡ Electricity Department
- `"Big pothole on the main road"` → 🛣️ Roads Department
- `"Garbage not collected for a week"` → ♻️ Sanitation Department
- `"I have a complaint about municipality"` → 🏛️ General Department

---

## 🔧 Tech Stack

| Layer    | Technology          |
|----------|---------------------|
| Backend  | Python 3, Flask     |
| Frontend | HTML5, CSS3, Vanilla JS |
| Routing  | Keyword-based logic |
| Storage  | In-memory (Python list) |

> **Note**: Data resets on server restart (no database). For persistence, connect SQLite or MongoDB.

---

## 🌟 Features

- ✅ Smart keyword-based complaint routing
- ✅ Auto-generated unique ticket ID
- ✅ Live department chip highlighting as you type
- ✅ Response time SLA shown per department
- ✅ Live complaint log in sidebar
- ✅ Toast notifications for feedback
- ✅ Premium dark-mode UI
- ✅ Mobile-responsive design
- ✅ No page reload (AJAX-based)

---

*Built as a mini project demonstrating Flask + frontend integration with intelligent routing.*
