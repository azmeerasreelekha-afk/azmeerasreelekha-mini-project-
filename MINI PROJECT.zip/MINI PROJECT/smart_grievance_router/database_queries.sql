-- Smart Grievance Router - Useful SQL Queries
-- Collection of commonly used queries for database management and reporting

-- =====================================================
-- BASIC QUERIES
-- =====================================================

-- Count all records in each table
SELECT 'Users' as table_name, COUNT(*) as count FROM users
UNION ALL
SELECT 'Admins', COUNT(*) FROM admins
UNION ALL
SELECT 'Complaints', COUNT(*) FROM complaints;

-- =====================================================
-- USER MANAGEMENT QUERIES
-- =====================================================

-- Get all active users
SELECT id, email, name, phone, created_at, status
FROM users
WHERE status = 'active'
ORDER BY created_at DESC;

-- Get user login history (if you add login tracking)
-- SELECT u.name, u.email, l.login_time, l.ip_address
-- FROM users u
-- JOIN user_logins l ON u.id = l.user_id
-- ORDER BY l.login_time DESC;

-- =====================================================
-- COMPLAINT ANALYSIS QUERIES
-- =====================================================

-- Complaints by status
SELECT status, COUNT(*) as count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM complaints), 2) as percentage
FROM complaints
GROUP BY status
ORDER BY count DESC;

-- Complaints by department
SELECT department, COUNT(*) as count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM complaints), 2) as percentage
FROM complaints
GROUP BY department
ORDER BY count DESC;

-- Complaints by user
SELECT u.name, u.email, COUNT(c.id) as complaint_count
FROM users u
LEFT JOIN complaints c ON u.email = c.user_email
GROUP BY u.id, u.name, u.email
ORDER BY complaint_count DESC;

-- Average complaints per user
SELECT AVG(complaint_count) as avg_complaints_per_user
FROM (
    SELECT COUNT(c.id) as complaint_count
    FROM users u
    LEFT JOIN complaints c ON u.email = c.user_email
    GROUP BY u.id
);

-- =====================================================
-- TIME-BASED ANALYSIS
-- =====================================================

-- Complaints by month
SELECT strftime('%Y-%m', timestamp) as month,
       COUNT(*) as count
FROM complaints
GROUP BY strftime('%Y-%m', timestamp)
ORDER BY month DESC;

-- Complaints by day of week
SELECT CASE strftime('%w', timestamp)
           WHEN '0' THEN 'Sunday'
           WHEN '1' THEN 'Monday'
           WHEN '2' THEN 'Tuesday'
           WHEN '3' THEN 'Wednesday'
           WHEN '4' THEN 'Thursday'
           WHEN '5' THEN 'Friday'
           WHEN '6' THEN 'Saturday'
       END as day_of_week,
       COUNT(*) as count
FROM complaints
GROUP BY strftime('%w', timestamp)
ORDER BY strftime('%w', timestamp);

-- Complaints by hour of day
SELECT strftime('%H', timestamp) as hour,
       COUNT(*) as count
FROM complaints
GROUP BY strftime('%H', timestamp)
ORDER BY hour;

-- =====================================================
-- SLA ANALYSIS
-- =====================================================

-- SLA compliance by department
SELECT department,
       sla,
       COUNT(*) as total_complaints,
       COUNT(CASE WHEN status = 'Resolved' THEN 1 END) as resolved_complaints,
       ROUND(COUNT(CASE WHEN status = 'Resolved' THEN 1 END) * 100.0 / COUNT(*), 2) as resolution_rate
FROM complaints
GROUP BY department, sla
ORDER BY department;

-- Average resolution time (if you add resolution timestamps)
-- SELECT department,
--        AVG(julianday(resolved_at) - julianday(timestamp)) as avg_resolution_days
-- FROM complaints
-- WHERE status = 'Resolved' AND resolved_at IS NOT NULL
-- GROUP BY department;

-- =====================================================
-- SEARCH AND FILTER QUERIES
-- =====================================================

-- Search complaints by keyword
SELECT ticket_id, name, department, complaint_text, status, timestamp
FROM complaints
WHERE complaint_text LIKE '%water%' OR complaint_text LIKE '%leak%'
ORDER BY timestamp DESC;

-- Find complaints by user
SELECT ticket_id, department, complaint_text, status, timestamp
FROM complaints
WHERE user_email = 'user@example.com'
ORDER BY timestamp DESC;

-- Find complaints by status and department
SELECT ticket_id, name, complaint_text, timestamp
FROM complaints
WHERE status = 'Received' AND department = 'Water Department'
ORDER BY timestamp DESC;

-- =====================================================
-- ADMIN MANAGEMENT QUERIES
-- =====================================================

-- Get all admins
SELECT id, username, name, created_at, status
FROM admins
ORDER BY created_at DESC;

-- Complaints assigned to each admin
SELECT a.name as admin_name,
       COUNT(c.id) as assigned_complaints
FROM admins a
LEFT JOIN complaints c ON a.id = c.assigned_to
GROUP BY a.id, a.name
ORDER BY assigned_complaints DESC;

-- =====================================================
-- MAINTENANCE QUERIES
-- =====================================================

-- Find duplicate ticket IDs (should not happen)
SELECT ticket_id, COUNT(*) as count
FROM complaints
GROUP BY ticket_id
HAVING COUNT(*) > 1;

-- Find complaints without valid users
SELECT c.ticket_id, c.user_email, c.name
FROM complaints c
LEFT JOIN users u ON c.user_email = u.email
WHERE u.id IS NULL;

-- Database size information
SELECT 'Database Size' as info,
       ROUND((SELECT SUM(pgsize) FROM dbstat) / 1024.0 / 1024.0, 2) || ' MB' as value
UNION ALL
SELECT 'Table Count',
       COUNT(*) as value
FROM sqlite_master
WHERE type = 'table'
UNION ALL
SELECT 'Index Count',
       COUNT(*) as value
FROM sqlite_master
WHERE type = 'index';

-- =====================================================
-- EXPORT QUERIES
-- =====================================================

-- Export all complaints for backup
SELECT * FROM complaints ORDER BY timestamp DESC;

-- Export user data
SELECT id, email, name, phone, created_at, status FROM users ORDER BY id;

-- Export admin data
SELECT id, username, name, created_at, status FROM admins ORDER BY id;