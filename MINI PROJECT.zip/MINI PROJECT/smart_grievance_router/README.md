# 🏛️ Smart Grievance Router
### AI-Powered Citizen Complaint Routing System
> Mini Project · 2nd Year Engineering · 2025–26

---

## 📁 Project Structure

```
smart_grievance_router/
│
├── app.py                     ← Flask backend (routing logic + auth + API endpoints)
├── database.py                ← SQLite database operations and utilities
├── db_manager.py              ← Database management script
├── setup_database.py          ← SQL-based database setup script
├── run_queries.py             ← SQL query runner for database analysis
├── test_app.py                ← Application testing script
├── test_db.py                 ← Database testing script
├── grievance_system.db        ← SQLite database file
├── database_schema.sql        ← SQL schema definition
├── database_data.sql          ← SQL test data
├── database_queries.sql       ← Useful SQL queries for analysis
├── requirements.txt           ← Python dependencies
├── README.md                  ← This file
│
└── templates/
    ├── login.html             ← Login page (User & Admin tabs)
    ├── user_dashboard.html    ← User dashboard (submit complaints, view history)
    ├── admin_dashboard.html   ← Admin dashboard (view all complaints, stats)
    └── index.html             ← Public grievance submission page
```

---
## 🗄️ Database Setup

### Database Type
- **SQLite** - Lightweight, file-based SQL database
- **File**: `grievance_system.db`
- **Auto-initialized** on first app run

### Database Tables

#### `users` - User Accounts
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'active'
);
```

#### `admins` - Admin Accounts
```sql
CREATE TABLE admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'active'
);
```

#### `complaints` - Complaint Records
```sql
CREATE TABLE complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT UNIQUE NOT NULL,
    user_email TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    complaint_text TEXT NOT NULL,
    category TEXT,
    department TEXT NOT NULL,
    icon TEXT,
    color TEXT,
    sla TEXT,
    contact TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'Received',
    assigned_to INTEGER,
    notes TEXT,
    FOREIGN KEY (user_email) REFERENCES users(email),
    FOREIGN KEY (assigned_to) REFERENCES admins(id)
);
```

### Database Management

Use the `db_manager.py` script for database operations:

```bash
# Initialize/reset database
python db_manager.py init

# Add default test data
python db_manager.py seed

# Show detailed statistics
python db_manager.py stats

# Create database backup
python db_manager.py backup

# Clear all complaints (keep users/admins)
python db_manager.py clear

# Reset entire database (WARNING: deletes all data)
python db_manager.py reset
```

### SQL Database Files

The project includes pure SQL files for database management:

- **`database_schema.sql`** - Complete database schema with tables, indexes, and triggers
- **`database_data.sql`** - Test data for users, admins, and sample complaints
- **`database_queries.sql`** - Useful SQL queries for analysis and reporting

#### Setting up Database from SQL Files

```bash
# Create fresh database from SQL files
python setup_database.py

# Run specific SQL queries
python run_queries.py list          # List available queries
python run_queries.py run 1         # Run query #1
python run_queries.py custom "SELECT * FROM users"
```

#### Manual SQL Execution

You can also execute the SQL files directly using SQLite:

```bash
# Create database from schema
sqlite3 grievance_system.db < database_schema.sql

# Insert test data
sqlite3 grievance_system.db < database_data.sql

# Run queries interactively
sqlite3 grievance_system.db
.schema
SELECT * FROM users;
.quit
```

### Test Database Connection

```bash
python test_db.py
```

---
## � User Authentication

### Test Credentials

#### 👤 User Accounts
| Email | Password |
|-------|----------|
| user@example.com | user123 |
| test@test.com | test123 |

#### 👨‍💼 Admin Accounts
| Username | Password |
|----------|----------|
| admin | admin123 |
| staff | staff123 |

### Login Flow
1. Visit http://127.0.0.1:5000 (automatically redirects to login)
2. Choose **User** or **Admin** tab
3. Enter credentials and click login
4. Access the respective dashboard

---

## �🚀 How to Run

### Step 1 — Install Python
Make sure Python 3.8+ is installed.
```bash
python --version
```

### Step 2 — Create a Virtual Environment (recommended)
```bash
python -m venv venv

# Activate on Windows:
venv\Scripts\activate

# Activate on Mac/Linux:
source venv/bin/activate
```

### Step 3 — Install Flask
```bash
pip install -r requirements.txt
```

### Step 4 — Run the App
```bash
python app.py
```

### Step 5 — Open in Browser
Visit: **http://127.0.0.1:5000**

---

## 🧠 How the Code Works

### 1. Backend — `app.py`

#### A. Department Rules Dictionary
```python
DEPARTMENT_RULES = [
    {
        "name": "Water Department",
        "keywords": ["water", "leakage", "pipe", ...],
        ...
    },
    ...
]
```
Each department has a list of keywords. When a complaint comes in, the system checks which department's keywords appear in the complaint text.

#### B. Routing Function
```python
def route_complaint(text: str) -> dict:
    lower = text.lower()          # Convert to lowercase for case-insensitive matching
    for dept in DEPARTMENT_RULES:
        for kw in dept["keywords"]:
            if kw in lower:       # If keyword found → return that department
                return dept
    return GENERAL_DEPT           # No match → General Department
```
This is simple keyword-based logic. No ML or AI involved.

#### C. Flask Routes
| Route | Method | Purpose |
|-------|--------|---------|
| `/` | GET | Redirects to login page |
| `/login` | GET | Serves login page |
| `/login-user` | POST | Authenticates user credentials |
| `/login-admin` | POST | Authenticates admin credentials |
| `/user-dashboard` | GET | User dashboard (protected) |
| `/admin-dashboard` | GET | Admin dashboard (protected) |
| `/logout` | GET | Clears session and redirects to login |
| `/api/user-info` | GET | Returns logged-in user info (API) |
| `/api/admin-info` | GET | Returns logged-in admin info (API) |
| `/api/user-complaints` | GET | Returns user's complaints (API) |
| `/api/all-complaints` | GET | Returns all complaints for admin (API) |
| `/submit` | POST | Receives complaint JSON, routes it, returns result |
| `/complaints` | GET | Returns all complaints (public log) |

#### D. Ticket ID Generation
```python
def generate_ticket_id():
    chars = string.ascii_uppercase + string.digits
    return "GR-" + "".join(random.choices(chars, k=8))
# Example output: GR-X7K2MN4A
```

---

### 2. Frontend — `templates/index.html`

#### A. Form Submission (JavaScript)
```javascript
async function submitComplaint() {
    const res = await fetch('/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, complaint }),
    });
    const data = await res.json();
    // Display the result card with department info
}
```
Uses the **Fetch API** to send data to Flask without page reload (AJAX).

#### B. Live Keyword Highlighting
As the user types, JavaScript checks for department keywords and highlights the relevant department chip in real time.

#### C. Result Display
After submission, the form is hidden and a result card is shown with:
- Ticket ID (unique per complaint)
- Department assigned
- SLA (expected response time)
- Contact email
- Timestamp

---

## 🏢 Department Routing Logic

| Department         | Keywords                                        | SLA    |
|--------------------|-------------------------------------------------|--------|
| 💧 Water           | water, leakage, leak, pipe, tap, drain, sewage  | 48 hrs |
| ⚡ Electricity      | electricity, power, current, outage, light      | 24 hrs |
| 🛣️ Roads           | road, pothole, street, highway, footpath        | 72 hrs |
| ♻️ Sanitation      | garbage, waste, cleaning, trash, dirty, smell   | 36 hrs |
| 🏛️ General        | (no keyword match)                              | 96 hrs |

---

## 🧪 Test Complaints

Try submitting these to test routing:
- `"There is water leakage near my house"` → 💧 Water Department
- `"Power outage for 3 hours in our area"` → ⚡ Electricity Department
- `"Big pothole on the main road"` → 🛣️ Roads Department
- `"Garbage not collected for a week"` → ♻️ Sanitation Department
- `"I have a complaint about municipality"` → 🏛️ General Department

---

## 🔧 Tech Stack

| Layer | Technology |
|-------|------------|
| Backend | Python 3, Flask |
| Authentication | Flask Sessions |
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Routing | Keyword-based logic |
| Storage | In-memory (Python list) |

> **Note**: Data resets on server restart (no database). For persistence, connect SQLite or MongoDB.

---

## ⚠️ Security Notes

**For Development Only:**
- User and admin credentials are stored in-memory and hardcoded
- Passwords are not hashed (plaintext comparison)
- Secret key is default (should use environment variables)
- HTTPS not enabled
- No CSRF protection

**For Production:**
- Implement proper database with hashed passwords (bcrypt)
- Use environment variables for secret keys
- Enable HTTPS/SSL
- Add CSRF tokens
- Implement rate limiting
- Add input validation & sanitization
- Use secure session cookies
- Add audit logging

---

## 🌟 Features

- ✅ Smart keyword-based complaint routing
- ✅ User & Admin authentication with session management
- ✅ Separate user dashboard (submit complaints, track history)
- ✅ Admin dashboard (view all complaints, stats, filters)
- ✅ Auto-generated unique ticket ID
- ✅ Live department chip highlighting as you type
- ✅ Response time SLA shown per department
- ✅ Live complaint log in sidebar
- ✅ Toast notifications for feedback
- ✅ Premium UI with gradient backgrounds
- ✅ Mobile-responsive design
- ✅ No page reload (AJAX-based)

---

## 📊 Dashboard Features

### 👤 User Dashboard
- Submit new complaints with category selection
- View personal complaint history
- Track complaint status (Received, In Progress, Resolved)
- Statistics: Total complaints, Resolved count
- Auto-refresh every 30 seconds
- Secure logout

### 👨‍💼 Admin Dashboard
- View all submitted complaints with filters
- Filter by status (Received, In Progress, Resolved)
- Department-wise complaint breakdown
- Real-time statistics (Total, Pending, In Progress, Resolved)
- Auto-refresh every 10 seconds
- Secure logout

---

*Built as a mini project demonstrating Flask + frontend integration with intelligent routing.*
