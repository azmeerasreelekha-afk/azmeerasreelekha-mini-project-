#!/usr/bin/env python3
"""Quick test script to verify the Smart Grievance Router is working."""

import urllib.request
import json
import time

def test_endpoint(url, description):
    """Test an endpoint and return the result."""
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            data = response.read().decode('utf-8')
            if response.headers.get('content-type', '').startswith('application/json'):
                data = json.loads(data)
                return f"✓ {description}: {len(data) if isinstance(data, list) else 'OK'} items"
            else:
                return f"✓ {description}: HTML page loaded"
    except Exception as e:
        return f"✗ {description}: {str(e)}"

def main():
    """Run all tests."""
    print("🧪 Testing Smart Grievance Router")
    print("=" * 40)

    base_url = "http://127.0.0.1:5000"

    # Wait a moment for the server to be ready
    time.sleep(2)

    tests = [
        (f"{base_url}/", "Homepage redirect"),
        (f"{base_url}/login", "Login page"),
        (f"{base_url}/complaints", "Complaints API"),
    ]

    for url, desc in tests:
        result = test_endpoint(url, desc)
        print(result)

    print("\n" + "=" * 40)
    print("🎯 Test Credentials:")
    print("👤 Users: user@example.com / user123")
    print("👨‍💼 Admins: admin / admin123")
    print("\n🌐 Open browser to: http://127.0.0.1:5000")
    print("📊 Database: 10 sample complaints loaded")

if __name__ == '__main__':
    main()