import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), 'grievance_system.db')

def get_db_connection():
    """Get database connection with row factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """Initialize database with tables if they don't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    ''')
    
    # Create admins table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    ''')
    
    # Create complaints table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id TEXT UNIQUE NOT NULL,
            user_email TEXT NOT NULL,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            complaint_text TEXT NOT NULL,
            category TEXT,
            department TEXT NOT NULL,
            icon TEXT,
            color TEXT,
            sla TEXT,
            contact TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'Received',
            assigned_to INTEGER,
            notes TEXT,
            FOREIGN KEY (user_email) REFERENCES users(email),
            FOREIGN KEY (assigned_to) REFERENCES admins(id)
        )
    ''')
    
    # Create index on ticket_id for faster lookups
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_ticket_id ON complaints(ticket_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_email ON complaints(user_email)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_status ON complaints(status)')
    
    conn.commit()
    conn.close()

def add_default_users():
    """Add default test users if they don't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    test_users = [
        ('user@example.com', 'user123', 'John User', '9876543210'),
        ('test@test.com', 'test123', 'Test User', '9876543211'),
        ('demo@demo.com', 'demo123', 'Demo User', '9876543212'),
    ]
    
    for email, password, name, phone in test_users:
        try:
            cursor.execute('''
                INSERT INTO users (email, password, name, phone)
                VALUES (?, ?, ?, ?)
            ''', (email, password, name, phone))
        except sqlite3.IntegrityError:
            pass  # User already exists
    
    conn.commit()
    conn.close()

def add_default_admins():
    """Add default test admins if they don't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    test_admins = [
        ('admin', 'admin123', 'System Admin'),
        ('staff', 'staff123', 'Staff Admin'),
        ('manager', 'manager123', 'Manager Admin'),
    ]
    
    for username, password, name in test_admins:
        try:
            cursor.execute('''
                INSERT INTO admins (username, password, name)
                VALUES (?, ?, ?)
            ''', (username, password, name))
        except sqlite3.IntegrityError:
            pass  # Admin already exists
    
    conn.commit()
    conn.close()

def get_user_by_email(email):
    """Get user by email."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE email = ?', (email.lower(),))
    user = cursor.fetchone()
    conn.close()
    return user

def get_admin_by_username(username):
    """Get admin by username."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM admins WHERE username = ?', (username.lower(),))
    admin = cursor.fetchone()
    conn.close()
    return admin

def add_complaint(ticket_id, user_email, name, phone, email, complaint_text, 
                  category, department, icon, color, sla, contact, status='Received'):
    """Add a new complaint."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO complaints 
            (ticket_id, user_email, name, phone, email, complaint_text, category,
             department, icon, color, sla, contact, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (ticket_id, user_email, name, phone, email, complaint_text, category,
              department, icon, color, sla, contact, status))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error adding complaint: {e}")
        conn.close()
        return False

def get_all_complaints():
    """Get all complaints."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT ticket_id, user_email, name, phone, email, complaint_text, 
               category, department, icon, color, sla, contact, timestamp, status
        FROM complaints
        ORDER BY timestamp DESC
    ''')
    complaints = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return complaints

def get_user_complaints(user_email):
    """Get complaints by user email."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT ticket_id, user_email, name, phone, email, complaint_text,
               category, department, icon, color, sla, contact, timestamp, status
        FROM complaints
        WHERE user_email = ?
        ORDER BY timestamp DESC
    ''', (user_email.lower(),))
    complaints = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return complaints

def update_complaint_status(ticket_id, new_status):
    """Update complaint status."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE complaints
        SET status = ?
        WHERE ticket_id = ?
    ''', (new_status, ticket_id))
    conn.commit()
    conn.close()
    return True

def get_complaint_stats():
    """Get complaint statistics."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    total = cursor.execute('SELECT COUNT(*) FROM complaints').fetchone()[0]
    received = cursor.execute('SELECT COUNT(*) FROM complaints WHERE status = ?', ('Received',)).fetchone()[0]
    in_progress = cursor.execute('SELECT COUNT(*) FROM complaints WHERE status = ?', ('In Progress',)).fetchone()[0]
    resolved = cursor.execute('SELECT COUNT(*) FROM complaints WHERE status = ?', ('Resolved',)).fetchone()[0]
    
    conn.close()
    
    return {
        'total': total,
        'received': received,
        'in_progress': in_progress,
        'resolved': resolved
    }

def get_department_stats():
    """Get complaint statistics by department."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT department, COUNT(*) as count
        FROM complaints
        GROUP BY department
        ORDER BY count DESC
    ''')
    stats = {row['department']: row['count'] for row in cursor.fetchall()}
    conn.close()
    return stats

if __name__ == '__main__':
    init_database()
    add_default_users()
    add_default_admins()
    print("✓ Database initialized successfully")
    print("✓ Default users and admins created")
