#!/usr/bin/env python3
"""
SQL Query Runner for Smart Grievance Router Database

Execute SQL queries from the database_queries.sql file or run custom queries.
Usage:
  python run_queries.py list          # List all available queries
  python run_queries.py run <number>  # Run a specific query by number
  python run_queries.py custom "<sql>" # Run a custom SQL query
"""

import sqlite3
import os
import re
from pathlib import Path

DB_PATH = 'grievance_system.db'

def get_db_connection():
    """Get database connection."""
    if not os.path.exists(DB_PATH):
        print(f"✗ Database not found: {DB_PATH}")
        print("Run 'python setup_database.py' first")
        exit(1)
    return sqlite3.connect(DB_PATH)

def parse_queries():
    """Parse queries from the SQL file."""
    queries_file = Path(__file__).parent / 'database_queries.sql'
    if not queries_file.exists():
        print("✗ database_queries.sql not found")
        return []

    with open(queries_file, 'r', encoding='utf-8') as f:
        content = f.read()

    # Split by comment headers
    sections = re.split(r'^-- =+[\w\s]+=*$', content, flags=re.MULTILINE)
    queries = []

    for section in sections:
        section = section.strip()
        if not section or section.startswith('--'):
            continue

        # Extract query title from first comment
        lines = section.split('\n')
        title = "Unnamed Query"
        for line in lines:
            if line.strip().startswith('--') and not line.strip().startswith('---'):
                title = line.strip()[2:].strip()
                break

        # Remove comments and get SQL
        sql_lines = []
        for line in lines:
            line = line.strip()
            if not line.startswith('--'):
                sql_lines.append(line)

        sql = '\n'.join(sql_lines).strip()
        if sql:
            queries.append({'title': title, 'sql': sql})

    return queries

def list_queries():
    """List all available queries."""
    queries = parse_queries()
    if not queries:
        print("No queries found")
        return

    print("Available SQL Queries:")
    print("=" * 50)
    for i, query in enumerate(queries, 1):
        print(f"{i:2d}. {query['title']}")

def run_query(query_num):
    """Run a specific query by number."""
    queries = parse_queries()
    if not queries:
        return

    try:
        query = queries[query_num - 1]
    except IndexError:
        print(f"✗ Query number {query_num} not found")
        return

    print(f"Executing: {query['title']}")
    print("-" * 50)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(query['sql'])
        results = cursor.fetchall()

        if results:
            # Get column names
            columns = [desc[0] for desc in cursor.description]

            # Print header
            print(" | ".join(f"{col:<15}" for col in columns))
            print("-" * (len(columns) * 18 - 2))

            # Print rows
            for row in results:
                print(" | ".join(f"{str(cell):<15}" for cell in row))
        else:
            print("No results returned")

        print(f"\n✓ Query executed successfully ({len(results)} rows)")

    except Exception as e:
        print(f"✗ Query execution failed: {e}")
    finally:
        conn.close()

def run_custom_query(sql):
    """Run a custom SQL query."""
    print("Executing custom query:")
    print("-" * 30)
    print(sql)
    print("-" * 30)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()

        if results:
            columns = [desc[0] for desc in cursor.description]
            print(" | ".join(f"{col:<15}" for col in columns))
            print("-" * (len(columns) * 18 - 2))
            for row in results:
                print(" | ".join(f"{str(cell):<15}" for cell in row))
        else:
            print("No results returned")

        print(f"\n✓ Custom query executed successfully ({len(results)} rows)")

    except Exception as e:
        print(f"✗ Query execution failed: {e}")
    finally:
        conn.close()

def main():
    """Main function."""
    if len(os.sys.argv) < 2:
        print(__doc__)
        return

    command = os.sys.argv[1].lower()

    if command == 'list':
        list_queries()
    elif command == 'run':
        if len(os.sys.argv) < 3:
            print("Usage: python run_queries.py run <query_number>")
            return
        try:
            query_num = int(os.sys.argv[2])
            run_query(query_num)
        except ValueError:
            print("✗ Invalid query number")
    elif command == 'custom':
        if len(os.sys.argv) < 3:
            print("Usage: python run_queries.py custom \"<sql_query>\"")
            return
        sql = " ".join(os.sys.argv[2:])
        run_custom_query(sql)
    else:
        print(__doc__)

if __name__ == '__main__':
    main()