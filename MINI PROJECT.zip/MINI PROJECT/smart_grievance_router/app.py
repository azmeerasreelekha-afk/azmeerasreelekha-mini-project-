from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from datetime import datetime
import random
import string
import os
from database import (
    init_database, add_default_users, add_default_admins,
    get_user_by_email, get_admin_by_username,
    add_complaint, get_all_complaints, get_user_complaints,
    update_complaint_status, get_complaint_stats, get_department_stats
)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'smart-grievance-router-secret-key-2024')

# Initialize database on startup
init_database()
add_default_users()
add_default_admins()

# ─────────────────────────────────────────────
#  Department keyword rules
# ─────────────────────────────────────────────
DEPARTMENT_RULES = [
    {
        "name": "Water Department",
        "keywords": ["water", "leakage", "leak", "pipe", "tap", "drainage", "flood", "sewage"],
        "icon": "💧",
        "color": "#3b82f6",
        "sla": "48 hours",
        "contact": "water@smartcity.gov",
    },
    {
        "name": "Electricity Department",
        "keywords": ["electricity", "electric", "power", "current", "voltage", "transformer",
                     "wire", "outage", "blackout", "light", "streetlight"],
        "icon": "⚡",
        "color": "#f59e0b",
        "sla": "24 hours",
        "contact": "electricity@smartcity.gov",
    },
    {
        "name": "Roads Department",
        "keywords": ["road", "pothole", "street", "highway", "pavement", "footpath",
                     "traffic", "signal", "divider", "bridge"],
        "icon": "🛣️",
        "color": "#10b981",
        "sla": "72 hours",
        "contact": "roads@smartcity.gov",
    },
    {
        "name": "Sanitation Department",
        "keywords": ["garbage", "waste", "cleaning", "trash", "dustbin", "bin", "litter",
                     "smell", "sewage", "drain", "hygiene", "dirty"],
        "icon": "♻️",
        "color": "#8b5cf6",
        "sla": "36 hours",
        "contact": "sanitation@smartcity.gov",
    },
]

GENERAL_DEPT = {
    "name": "General Department",
    "icon": "🏛️",
    "color": "#64748b",
    "sla": "96 hours",
    "contact": "general@smartcity.gov",
}


def generate_ticket_id():
    chars = string.ascii_uppercase + string.digits
    return "GR-" + "".join(random.choices(chars, k=8))


def route_complaint(text: str) -> dict:
    """Keyword-based routing logic."""
    lower = text.lower()
    for dept in DEPARTMENT_RULES:
        for kw in dept["keywords"]:
            if kw in lower:
                return dept
    return GENERAL_DEPT


# In-memory complaint log (now using database)
complaints_log = []


# ─────────────────────────────────────────────
#  Routes
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return redirect(url_for('login_page'))


@app.route("/login")
def login_page():
    return render_template("login.html")


@app.route("/login-user", methods=["POST"])
def login_user():
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "").strip()

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    user = get_user_by_email(email)
    if user and user['password'] == password:
        session["user_type"] = "user"
        session["user_email"] = email
        session["user_name"] = user['name']
        return jsonify({"success": True, "message": "Login successful"})
    else:
        return jsonify({"error": "Invalid email or password"}), 401


@app.route("/login-admin", methods=["POST"])
def login_admin():
    data = request.get_json()
    username = data.get("username", "").strip().lower()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    admin = get_admin_by_username(username)
    if admin and admin['password'] == password:
        session["user_type"] = "admin"
        session["admin_username"] = username
        session["admin_name"] = admin['name']
        return jsonify({"success": True, "message": "Admin login successful"})
    else:
        return jsonify({"error": "Invalid username or password"}), 401


@app.route("/user-dashboard")
def user_dashboard():
    if session.get("user_type") != "user":
        return redirect(url_for("login_page"))
    return render_template("user_dashboard.html")


@app.route("/admin-dashboard")
def admin_dashboard():
    if session.get("user_type") != "admin":
        return redirect(url_for("login_page"))
    return render_template("admin_dashboard.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login_page"))


# ─────────────────────────────────────────────
#  API Routes for Dashboards
# ─────────────────────────────────────────────
@app.route("/api/user-info")
def api_user_info():
    if session.get("user_type") != "user":
        return jsonify({"success": False, "error": "Unauthorized"}), 401
    
    return jsonify({
        "success": True,
        "user_email": session.get("user_email"),
        "user_name": session.get("user_name")
    })


@app.route("/api/admin-info")
def api_admin_info():
    if session.get("user_type") != "admin":
        return jsonify({"success": False, "error": "Unauthorized"}), 401
    
    return jsonify({
        "success": True,
        "admin_username": session.get("admin_username"),
        "admin_name": session.get("admin_name")
    })


@app.route("/api/user-complaints")
def api_user_complaints():
    if session.get("user_type") != "user":
        return jsonify({"success": False, "error": "Unauthorized"}), 401
    
    user_email = session.get("user_email")
    user_complaints = get_user_complaints(user_email)
    
    return jsonify({
        "success": True,
        "complaints": user_complaints
    })


@app.route("/api/all-complaints")
def api_all_complaints():
    if session.get("user_type") != "admin":
        return jsonify({"success": False, "error": "Unauthorized"}), 401
    
    complaints = get_all_complaints()
    return jsonify({
        "success": True,
        "complaints": complaints
    })


# ─────────────────────────────────────────────
#  Original Routes
# ─────────────────────────────────────────────
@app.route("/submit", methods=["POST"])
def submit():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    complaint = data.get("complaint", "").strip()

    if session.get("user_type") == "user":
        # Always tie user submissions to the logged-in account.
        email = session.get("user_email", email).strip().lower()
        if not name:
            name = session.get("user_name", "").strip()

    if not name or not complaint:
        return jsonify({"error": "Name and complaint are required."}), 400

    dept = route_complaint(complaint)
    ticket_id = generate_ticket_id()
    timestamp = datetime.now().strftime("%d %b %Y, %I:%M %p")

    # Save to database
    success = add_complaint(
        ticket_id=ticket_id,
        user_email=email if email else "anonymous",
        name=name,
        phone=data.get("phone", ""),
        email=email if email else None,
        complaint_text=complaint,
        category=data.get("category", ""),
        department=dept["name"],
        icon=dept["icon"],
        color=dept["color"],
        sla=dept["sla"],
        contact=dept["contact"]
    )

    if not success:
        return jsonify({"error": "Failed to submit complaint."}), 500

    entry = {
        "ticket_id": ticket_id,
        "name": name,
        "email": email,
        "complaint": complaint,
        "department": dept["name"],
        "icon": dept["icon"],
        "color": dept["color"],
        "sla": dept["sla"],
        "contact": dept["contact"],
        "timestamp": timestamp,
        "status": "Received",
    }

    return jsonify(entry)


@app.route("/complaints")
def complaints():
    return jsonify(get_all_complaints())


if __name__ == "__main__":
    app.run(debug=True)
