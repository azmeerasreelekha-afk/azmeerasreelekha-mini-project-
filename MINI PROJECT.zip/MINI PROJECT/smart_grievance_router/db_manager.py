#!/usr/bin/env python3
"""
Database Management Script for Smart Grievance Router

Usage:
  python db_manager.py init      # Initialize/reset database
  python db_manager.py seed      # Add default test data
  python db_manager.py stats     # Show database statistics
  python db_manager.py backup    # Create database backup
  python db_manager.py clear     # Clear all complaints (keep users/admins)
"""

import sqlite3
import os
import shutil
from datetime import datetime
from database import (
    init_database, add_default_users, add_default_admins,
    get_db_connection, get_complaint_stats, get_department_stats
)

def backup_database():
    """Create a backup of the database."""
    db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
    backup_path = f"{db_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    try:
        shutil.copy2(db_path, backup_path)
        print(f"✓ Database backup created: {backup_path}")
        return True
    except Exception as e:
        print(f"✗ Backup failed: {e}")
        return False

def clear_complaints():
    """Clear all complaints but keep users and admins."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('DELETE FROM complaints')
        cursor.execute('DELETE FROM sqlite_sequence WHERE name="complaints"')
        conn.commit()
        print("✓ All complaints cleared")
    except Exception as e:
        print(f"✗ Failed to clear complaints: {e}")
    finally:
        conn.close()

def show_detailed_stats():
    """Show detailed database statistics."""
    conn = get_db_connection()
    cursor = conn.cursor()

    print("\n" + "="*50)
    print("DETAILED DATABASE STATISTICS")
    print("="*50)

    # User stats
    cursor.execute('SELECT COUNT(*) FROM users')
    user_count = cursor.fetchone()[0]
    print(f"👤 Total Users: {user_count}")

    # Admin stats
    cursor.execute('SELECT COUNT(*) FROM admins')
    admin_count = cursor.fetchone()[0]
    print(f"👨‍💼 Total Admins: {admin_count}")

    # Complaint stats
    stats = get_complaint_stats()
    print(f"\n📊 COMPLAINT STATISTICS:")
    print(f"  Total: {stats['total']}")
    print(f"  Received: {stats['received']}")
    print(f"  In Progress: {stats['in_progress']}")
    print(f"  Resolved: {stats['resolved']}")

    # Department breakdown
    dept_stats = get_department_stats()
    if dept_stats:
        print(f"\n🏢 DEPARTMENT BREAKDOWN:")
        for dept, count in sorted(dept_stats.items(), key=lambda x: x[1], reverse=True):
            print(f"  {dept}: {count}")

    # Recent activity
    cursor.execute('''
        SELECT ticket_id, department, status, timestamp
        FROM complaints
        ORDER BY timestamp DESC
        LIMIT 5
    ''')
    recent = cursor.fetchall()

    if recent:
        print(f"\n📋 RECENT COMPLAINTS:")
        for complaint in recent:
            print(f"  {complaint[0]} - {complaint[1]} - {complaint[2]} - {complaint[3]}")

    # Database file info
    db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
    db_size = os.path.getsize(db_path) if os.path.exists(db_path) else 0
    print(f"\n💾 DATABASE INFO:")
    print(f"  File: {db_path}")
    print(f"  Size: {db_size:,} bytes ({db_size/1024:.1f} KB)")

    conn.close()

def reset_database():
    """Reset the entire database."""
    print("⚠️  WARNING: This will delete ALL data!")
    confirm = input("Are you sure you want to reset the database? (type 'YES' to confirm): ")

    if confirm.upper() == 'YES':
        # Backup first
        backup_database()

        # Remove old database
        db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
        if os.path.exists(db_path):
            os.remove(db_path)

        # Recreate
        init_database()
        add_default_users()
        add_default_admins()
        print("✓ Database reset complete")
    else:
        print("Database reset cancelled")

def main():
    """Main function to handle command line arguments."""
    if len(os.sys.argv) < 2:
        print(__doc__)
        return

    command = os.sys.argv[1].lower()

    if command == 'init':
        print("Initializing database...")
        init_database()
        print("✓ Database initialized")

    elif command == 'seed':
        print("Adding default test data...")
        add_default_users()
        add_default_admins()
        print("✓ Test data added")

    elif command == 'stats':
        show_detailed_stats()

    elif command == 'backup':
        backup_database()

    elif command == 'clear':
        print("Clearing all complaints...")
        clear_complaints()

    elif command == 'reset':
        reset_database()

    else:
        print(f"Unknown command: {command}")
        print(__doc__)

if __name__ == '__main__':
    main()