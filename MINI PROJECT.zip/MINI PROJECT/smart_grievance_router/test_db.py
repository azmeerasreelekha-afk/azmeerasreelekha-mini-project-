#!/usr/bin/env python3
"""Test script to verify database connection and structure."""

from database import get_db_connection, get_complaint_stats, get_department_stats

def test_database():
    """Test database connection and show statistics."""
    try:
        # Test connection
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get all tables
        cursor.execute('SELECT name FROM sqlite_master WHERE type="table"')
        tables = cursor.fetchall()
        print("✓ Database connected successfully!")
        print("Database tables:", [table[0] for table in tables])

        # Show table structures
        for table_name in ['users', 'admins', 'complaints']:
            cursor.execute(f'PRAGMA table_info({table_name})')
            columns = cursor.fetchall()
            print(f"\n{table_name.upper()} table structure:")
            for col in columns:
                print(f"  - {col[1]} ({col[2]}) {'PRIMARY KEY' if col[5] else ''}")

        # Show sample data
        print("\nSAMPLE DATA:")
        cursor.execute('SELECT COUNT(*) FROM users')
        user_count = cursor.fetchone()[0]
        print(f"Users: {user_count}")

        cursor.execute('SELECT COUNT(*) FROM admins')
        admin_count = cursor.fetchone()[0]
        print(f"Admins: {admin_count}")

        cursor.execute('SELECT COUNT(*) FROM complaints')
        complaint_count = cursor.fetchone()[0]
        print(f"Complaints: {complaint_count}")

        # Show recent complaints
        if complaint_count > 0:
            cursor.execute('SELECT ticket_id, department, status, timestamp FROM complaints ORDER BY timestamp DESC LIMIT 3')
            recent = cursor.fetchall()
            print("\nRecent complaints:")
            for complaint in recent:
                print(f"  {complaint[0]} - {complaint[1]} - {complaint[2]} - {complaint[3]}")

        conn.close()

        # Test stats functions
        print("\nSTATISTICS:")
        stats = get_complaint_stats()
        print(f"Total complaints: {stats['total']}")
        print(f"Received: {stats['received']}")
        print(f"In Progress: {stats['in_progress']}")
        print(f"Resolved: {stats['resolved']}")

        dept_stats = get_department_stats()
        if dept_stats:
            print("Department breakdown:")
            for dept, count in dept_stats.items():
                print(f"  {dept}: {count}")

    except Exception as e:
        print(f"✗ Database error: {e}")

if __name__ == '__main__':
    test_database()