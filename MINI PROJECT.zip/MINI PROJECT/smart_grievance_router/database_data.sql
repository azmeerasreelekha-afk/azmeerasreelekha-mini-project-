-- Smart Grievance Router Test Data
-- Insert default users, admins, and sample complaints

-- =====================================================
-- DEFAULT USERS
-- =====================================================
INSERT OR IGNORE INTO users (email, password, name, phone, status) VALUES
('user@example.com', 'user123', 'John User', '9876543210', 'active'),
('test@test.com', 'test123', 'Test User', '9876543211', 'active'),
('demo@demo.com', 'demo123', 'Demo User', '9876543212', 'active'),
('alice@example.com', 'alice123', 'Alice Johnson', '9876543213', 'active'),
('bob@example.com', 'bob123', 'Bob Smith', '9876543214', 'active');

-- =====================================================
-- DEFAULT ADMINS
-- =====================================================
INSERT OR IGNORE INTO admins (username, password, name, status) VALUES
('admin', 'admin123', 'System Admin', 'active'),
('staff', 'staff123', 'Staff Admin', 'active'),
('manager', 'manager123', 'Manager Admin', 'active'),
('supervisor', 'super123', 'Supervisor Admin', 'active');

-- =====================================================
-- SAMPLE COMPLAINTS
-- =====================================================
INSERT OR IGNORE INTO complaints (
    ticket_id, user_email, name, phone, email, complaint_text, category,
    department, icon, color, sla, contact, status
) VALUES
('GR-A1B2C3D4', 'user@example.com', 'John User', '9876543210', 'user@example.com',
 'There is a water leakage near my house that has been going on for 3 days. The water is coming from the main pipe and causing flooding in the street.',
 'water', 'Water Department', '💧', '#3b82f6', '48 hours', 'water@smartcity.gov', 'Received'),

('GR-E5F6G7H8', 'test@test.com', 'Test User', '9876543211', 'test@test.com',
 'Power outage in our neighborhood for the past 6 hours. Street lights are also not working. This is affecting our daily activities.',
 'electricity', 'Electricity Department', '⚡', '#f59e0b', '24 hours', 'electricity@smartcity.gov', 'In Progress'),

('GR-I9J0K1L2', 'demo@demo.com', 'Demo User', '9876543212', 'demo@demo.com',
 'There is a huge pothole on the main road near the school. It is very dangerous for vehicles and pedestrians. Several accidents have occurred.',
 'roads', 'Roads Department', '🛣️', '#10b981', '72 hours', 'roads@smartcity.gov', 'Resolved'),

('GR-M3N4O5P6', 'alice@example.com', 'Alice Johnson', '9876543213', 'alice@example.com',
 'Garbage has not been collected from our area for the past week. The waste is piling up and causing bad smell and health issues.',
 'sanitation', 'Sanitation Department', '♻️', '#8b5cf6', '36 hours', 'sanitation@smartcity.gov', 'Received'),

('GR-Q7R8S9T0', 'bob@example.com', 'Bob Smith', '9876543214', 'bob@example.com',
 'The traffic signal at the main intersection is not working properly. It is causing traffic congestion and safety concerns.',
 'roads', 'Roads Department', '🛣️', '#10b981', '72 hours', 'roads@smartcity.gov', 'In Progress'),

('GR-U1V2W3X4', 'user@example.com', 'John User', '9876543210', 'user@example.com',
 'Street light in front of our house is not working for the past month. It is very dark and unsafe at night.',
 'electricity', 'Electricity Department', '⚡', '#f59e0b', '24 hours', 'electricity@smartcity.gov', 'Resolved'),

('GR-Y5Z6A7B8', 'test@test.com', 'Test User', '9876543211', 'test@test.com',
 'There is a broken water pipe in the park that is wasting water continuously. This needs immediate attention.',
 'water', 'Water Department', '💧', '#3b82f6', '48 hours', 'water@smartcity.gov', 'Received'),

('GR-C9D0E1F2', 'demo@demo.com', 'Demo User', '9876543212', 'demo@demo.com',
 'The drainage system in our locality is blocked and causing water logging during rains. This leads to mosquito breeding.',
 'sanitation', 'Sanitation Department', '♻️', '#8b5cf6', '36 hours', 'sanitation@smartcity.gov', 'In Progress'),

('GR-G3H4I5J6', 'alice@example.com', 'Alice Johnson', '9876543213', 'alice@example.com',
 'Multiple potholes on the highway are making travel dangerous. The road condition is very poor and needs immediate repair.',
 'roads', 'Roads Department', '🛣️', '#10b981', '72 hours', 'roads@smartcity.gov', 'Received'),

('GR-K7L8M9N0', 'bob@example.com', 'Bob Smith', '9876543214', 'bob@example.com',
 'Power fluctuation in our area is damaging electrical appliances. The voltage is not stable and causes frequent outages.',
 'electricity', 'Electricity Department', '⚡', '#f59e0b', '24 hours', 'electricity@smartcity.gov', 'Resolved');