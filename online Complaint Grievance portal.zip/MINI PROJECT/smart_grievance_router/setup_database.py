#!/usr/bin/env python3
"""
SQL Database Setup Script for Smart Grievance Router.

This script creates and populates the SQLite database using SQL files.
Run this to set up the database from scratch.
"""

import os
import sqlite3
from pathlib import Path


def execute_sql_file(db_path, sql_file_path):
    """Execute SQL commands from a file."""
    if not os.path.exists(sql_file_path):
        print(f"SQL file not found: {sql_file_path}")
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        with open(sql_file_path, 'r', encoding='utf-8') as file:
            sql_script = file.read()

        cursor.executescript(sql_script)
        conn.commit()
        conn.close()
        print(f"Executed SQL file: {sql_file_path}")
        return True
    except Exception as error:
        print(f"Error executing {sql_file_path}: {error}")
        return False


def setup_database():
    """Set up the database using SQL files."""
    project_dir = Path(__file__).parent
    db_path = project_dir / 'grievance_system.db'
    schema_file = project_dir / 'database_schema.sql'
    data_file = project_dir / 'database_data.sql'

    print("Setting up Smart Grievance Router Database")
    print("=" * 50)

    if db_path.exists():
        print(f"Removing existing database: {db_path}")
        db_path.unlink()

    print("\nCreating database schema...")
    if not execute_sql_file(str(db_path), str(schema_file)):
        return False

    print("\nInserting test data...")
    if not execute_sql_file(str(db_path), str(data_file)):
        return False

    print("\nVerifying database setup...")
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        print(f"Tables created: {', '.join(tables)}")

        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM admins")
        admin_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM complaints")
        complaint_count = cursor.fetchone()[0]

        print(f"Data inserted: {user_count} users, {admin_count} admins, {complaint_count} complaints")
        conn.close()
    except Exception as error:
        print(f"Verification failed: {error}")
        return False

    print("\nDatabase setup completed successfully")
    print(f"Database file: {db_path}")
    print(f"Database size: {db_path.stat().st_size:,} bytes")
    return True


def show_usage_info():
    """Show information about using the database."""
    print("\n" + "=" * 50)
    print("USAGE INFORMATION")
    print("=" * 50)
    print("Test Credentials:")
    print("Users:")
    print("  user@example.com / user123")
    print("  test@test.com / test123")
    print("  demo@demo.com / demo123")
    print("  alice@example.com / alice123")
    print("  bob@example.com / bob123")
    print("\nAdmins:")
    print("  admin / admin123")
    print("  staff / staff123")
    print("  manager / manager123")
    print("  supervisor / super123")
    print("\nTo start the application:")
    print("  python app.py")
    print("\nTo manage the database:")
    print("  python db_manager.py stats")
    print("  python db_manager.py backup")


if __name__ == '__main__':
    success = setup_database()
    if success:
        show_usage_info()
    else:
        print("\nDatabase setup failed")
        raise SystemExit(1)
