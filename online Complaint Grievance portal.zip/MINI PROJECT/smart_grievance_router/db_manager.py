#!/usr/bin/env python3
"""
Database Management Script for Smart Grievance Router

Usage:
  python db_manager.py init
  python db_manager.py seed
  python db_manager.py stats
  python db_manager.py backup
  python db_manager.py clear
"""

import os
import shutil
from datetime import datetime

from database import (
    add_default_admins,
    add_default_users,
    get_complaint_stats,
    get_db_connection,
    get_department_stats,
    init_database,
)


def backup_database():
    """Create a backup of the database."""
    db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
    backup_path = f"{db_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    try:
        shutil.copy2(db_path, backup_path)
        print(f"Database backup created: {backup_path}")
        return True
    except Exception as error:
        print(f"Backup failed: {error}")
        return False


def clear_complaints():
    """Clear all complaints but keep users and admins."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('DELETE FROM complaints')
        cursor.execute('DELETE FROM sqlite_sequence WHERE name="complaints"')
        conn.commit()
        print("All complaints cleared")
    except Exception as error:
        print(f"Failed to clear complaints: {error}")
    finally:
        conn.close()


def show_detailed_stats():
    """Show detailed database statistics."""
    conn = get_db_connection()
    cursor = conn.cursor()

    print("\n" + "=" * 50)
    print("DETAILED DATABASE STATISTICS")
    print("=" * 50)

    cursor.execute('SELECT COUNT(*) FROM users')
    user_count = cursor.fetchone()[0]
    print(f"Total Users: {user_count}")

    cursor.execute('SELECT COUNT(*) FROM admins')
    admin_count = cursor.fetchone()[0]
    print(f"Total Admins: {admin_count}")

    stats = get_complaint_stats()
    print("\nCOMPLAINT STATISTICS:")
    print(f"  Total: {stats['total']}")
    print(f"  Received: {stats['received']}")
    print(f"  In Progress: {stats['in_progress']}")
    print(f"  Resolved: {stats['resolved']}")

    dept_stats = get_department_stats()
    if dept_stats:
        print("\nDEPARTMENT BREAKDOWN:")
        for dept, count in sorted(dept_stats.items(), key=lambda item: item[1], reverse=True):
            print(f"  {dept}: {count}")

    cursor.execute(
        '''
        SELECT ticket_id, department, status, timestamp
        FROM complaints
        ORDER BY timestamp DESC
        LIMIT 5
        '''
    )
    recent = cursor.fetchall()

    if recent:
        print("\nRECENT COMPLAINTS:")
        for complaint in recent:
            print(f"  {complaint[0]} - {complaint[1]} - {complaint[2]} - {complaint[3]}")

    db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
    db_size = os.path.getsize(db_path) if os.path.exists(db_path) else 0
    print("\nDATABASE INFO:")
    print(f"  File: {db_path}")
    print(f"  Size: {db_size:,} bytes ({db_size / 1024:.1f} KB)")

    conn.close()


def reset_database():
    """Reset the entire database."""
    print("WARNING: This will delete all data.")
    confirm = input("Type 'YES' to confirm database reset: ")

    if confirm.upper() == 'YES':
        backup_database()

        db_path = os.path.join(os.path.dirname(__file__), 'grievance_system.db')
        if os.path.exists(db_path):
            os.remove(db_path)

        init_database()
        add_default_users()
        add_default_admins()
        print("Database reset complete")
    else:
        print("Database reset cancelled")


def main():
    """Main function to handle command line arguments."""
    if len(os.sys.argv) < 2:
        print(__doc__)
        return

    command = os.sys.argv[1].lower()

    if command == 'init':
        print("Initializing database...")
        init_database()
        print("Database initialized")
    elif command == 'seed':
        print("Adding default test data...")
        add_default_users()
        add_default_admins()
        print("Test data added")
    elif command == 'stats':
        show_detailed_stats()
    elif command == 'backup':
        backup_database()
    elif command == 'clear':
        print("Clearing all complaints...")
        clear_complaints()
    elif command == 'reset':
        reset_database()
    else:
        print(f"Unknown command: {command}")
        print(__doc__)


if __name__ == '__main__':
    main()
