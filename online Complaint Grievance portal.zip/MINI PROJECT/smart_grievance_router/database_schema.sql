-- Smart Grievance Router Database Schema
-- SQLite Database Setup Script

-- =====================================================
-- USERS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'active'
);

-- =====================================================
-- ADMINS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'active'
);

-- =====================================================
-- COMPLAINTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT UNIQUE NOT NULL,
    user_email TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    complaint_text TEXT NOT NULL,
    location TEXT,
    category TEXT,
    department TEXT NOT NULL,
    icon TEXT,
    color TEXT,
    sla TEXT,
    contact TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'Received',
    assigned_to INTEGER,
    notes TEXT,
    FOREIGN KEY (user_email) REFERENCES users(email),
    FOREIGN KEY (assigned_to) REFERENCES admins(id)
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_ticket_id ON complaints(ticket_id);
CREATE INDEX IF NOT EXISTS idx_user_email ON complaints(user_email);
CREATE INDEX IF NOT EXISTS idx_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_timestamp ON complaints(timestamp);
CREATE INDEX IF NOT EXISTS idx_department ON complaints(department);

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Trigger to update timestamp on complaint updates
CREATE TRIGGER IF NOT EXISTS update_complaint_timestamp
    AFTER UPDATE ON complaints
    FOR EACH ROW
    WHEN NEW.timestamp = OLD.timestamp
BEGIN
    UPDATE complaints SET timestamp = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;