#!/usr/bin/env python3
"""Quick test script to verify the Smart Grievance Router is working."""

import json
import time
import urllib.request


def test_endpoint(url, description):
    """Test an endpoint and return the result."""
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            data = response.read().decode('utf-8')
            if response.headers.get('content-type', '').startswith('application/json'):
                data = json.loads(data)
                count = len(data) if isinstance(data, list) else 'OK'
                return f"[OK] {description}: {count} items"
            return f"[OK] {description}: HTML page loaded"
    except Exception as error:
        return f"[ERROR] {description}: {error}"


def main():
    """Run all tests."""
    print("Testing Smart Grievance Router")
    print("=" * 40)

    base_url = "http://127.0.0.1:5000"
    time.sleep(2)

    tests = [
        (f"{base_url}/", "Homepage redirect"),
        (f"{base_url}/login", "Login page"),
        (f"{base_url}/complaints", "Complaints API"),
    ]

    for url, description in tests:
        print(test_endpoint(url, description))

    print("\n" + "=" * 40)
    print("Test Credentials:")
    print("Users: user@example.com / user123")
    print("Admins: admin / admin123")
    print(f"\nOpen browser to: {base_url}")


if __name__ == '__main__':
    main()
