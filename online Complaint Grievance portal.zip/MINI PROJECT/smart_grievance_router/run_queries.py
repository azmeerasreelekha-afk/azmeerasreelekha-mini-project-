#!/usr/bin/env python3
"""
SQL Query Runner for Smart Grievance Router Database

Usage:
  python run_queries.py list
  python run_queries.py run <number>
  python run_queries.py custom "<sql>"
"""

import os
import re
import sqlite3
from pathlib import Path

DB_PATH = 'grievance_system.db'


def get_db_connection():
    """Get database connection."""
    if not os.path.exists(DB_PATH):
        print(f"Database not found: {DB_PATH}")
        print("Run 'python setup_database.py' first")
        raise SystemExit(1)
    return sqlite3.connect(DB_PATH)


def parse_queries():
    """Parse titled SQL queries from the SQL file."""
    queries_file = Path(__file__).parent / 'database_queries.sql'
    if not queries_file.exists():
        print("database_queries.sql not found")
        return []

    with open(queries_file, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    queries = []
    current_title = None
    current_sql_lines = []

    def flush_query():
        sql = '\n'.join(current_sql_lines).strip()
        if current_title and sql:
            queries.append({'title': current_title, 'sql': sql})

    for raw_line in lines:
        line = raw_line.rstrip('\n')
        stripped = line.strip()

        if not stripped:
            continue

        if re.match(r'^-- =+', stripped):
            continue

        if stripped.startswith('--'):
            comment = stripped[2:].strip()
            if comment and not current_sql_lines:
                current_title = comment
            continue

        current_sql_lines.append(line)
        if stripped.endswith(';'):
            flush_query()
            current_title = None
            current_sql_lines = []

    return queries


def list_queries():
    """List all available queries."""
    queries = parse_queries()
    if not queries:
        print("No queries found")
        return

    print("Available SQL Queries:")
    print("=" * 50)
    for index, query in enumerate(queries, 1):
        print(f"{index:2d}. {query['title']}")


def print_results(cursor, results):
    """Print query results in a simple table."""
    if not results:
        print("No results returned")
        return

    columns = [description[0] for description in cursor.description]
    print(" | ".join(f"{column:<15}" for column in columns))
    print("-" * (len(columns) * 18 - 2))

    for row in results:
        print(" | ".join(f"{str(cell):<15}" for cell in row))


def run_query(query_num):
    """Run a specific query by number."""
    queries = parse_queries()
    if not queries:
        return

    try:
        query = queries[query_num - 1]
    except IndexError:
        print(f"Query number {query_num} not found")
        return

    print(f"Executing: {query['title']}")
    print("-" * 50)

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(query['sql'])
        results = cursor.fetchall()
        print_results(cursor, results)
        print(f"\nQuery executed successfully ({len(results)} rows)")
    except Exception as error:
        print(f"Query execution failed: {error}")
    finally:
        if conn:
            conn.close()


def run_custom_query(sql):
    """Run a custom SQL query."""
    print("Executing custom query:")
    print("-" * 30)
    print(sql)
    print("-" * 30)

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        print_results(cursor, results)
        print(f"\nCustom query executed successfully ({len(results)} rows)")
    except Exception as error:
        print(f"Query execution failed: {error}")
    finally:
        if conn:
            conn.close()


def main():
    """Main function."""
    if len(os.sys.argv) < 2:
        print(__doc__)
        return

    command = os.sys.argv[1].lower()

    if command == 'list':
        list_queries()
    elif command == 'run':
        if len(os.sys.argv) < 3:
            print("Usage: python run_queries.py run <query_number>")
            return
        try:
            query_num = int(os.sys.argv[2])
            run_query(query_num)
        except ValueError:
            print("Invalid query number")
    elif command == 'custom':
        if len(os.sys.argv) < 3:
            print('Usage: python run_queries.py custom "<sql_query>"')
            return
        sql = " ".join(os.sys.argv[2:])
        run_custom_query(sql)
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
